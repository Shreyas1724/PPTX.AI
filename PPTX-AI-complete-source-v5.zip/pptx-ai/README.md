# PPTX.AI — Studio v3

An AI presentation workspace with a cinematic React interface, FastAPI services, verified registration, a transaction-safe credit wallet, durable background jobs, versioned editing, and real PPTX export.

## Start locally

1. Copy `.env.example` to `.env` and choose a strong PostgreSQL password.
2. Configure email/SMS verification for new signup. Google sign-in and paid credit purchases are optional integrations.
3. Add your LLM_API_KEY and model settings for AI generation and advanced editing. Without a key, the product explicitly identifies itself as Outline studio; basic outline generation and deterministic edit commands still work.
4. Run `docker compose up --build -d`.
5. Open `http://localhost:3000`. Development API docs: `http://localhost:3000/api/docs`.

Read **SECURITY-CREDITS-V3.md** before upgrading an existing installation. It covers credit invariants, queue recovery, payment setup, production settings, verification, and remaining limitations. Signup and Google configuration are also described in **UPGRADE-AUTH-HISTORY.md**, with v3 changes taking precedence.

## Product flow

Sign up → verify email and mobile → open your workspace → define a presentation → review the brief and credit cost → generate → edit manually or through the assistant → export PPTX.

The workspace includes search, starter prompts, recent activity, and real credit data. The wallet shows available, reserved, and spent credits, a paginated ledger, and recent operation states. History retains the last 100 days of task activity. From any real presentation viewer, **Mobile Control** creates a two-minute, single-use invitation. Scan it on a phone to open the mobile remote; the desktop viewer remains authoritative and receives typed, acknowledged WebSocket commands. Sessions, devices, replay protection, revocation, and audit events are persisted in additive control tables. Set `FRONTEND_URL` to the public HTTPS origin in production so pairing fragments never leave your site.

## Architecture

- `frontend/src/Workspace.tsx`, `CreateStudio.tsx`, `WalletPage.tsx`: workspace, creation review, and credit wallet.
- `frontend/src/AuthPage.tsx`, `HistoryPage.tsx`: verified registration, Google sign-in, and activity history.
- `frontend/src/HeroScene.tsx`: lazy-loaded interactive 3D with reduced-motion/static fallbacks.
- `backend/app/auth.py`: Google identity verification, dual OTP onboarding, rate limits, secure sessions.
- `backend/app/credits.py`: atomic reservations, idempotency fingerprints, refunds, and wallet aggregation.
- `backend/app/worker.py`: durable database queue, atomic claims, fenced commits, timeouts, and recovery.
- `backend/app/intelligence.py`: validated AI generation/editing, limited retries, and reference retrieval.
- `backend/app/billing.py`: Stripe Checkout, signature verification, and one-time credit fulfillment.
- `backend/app/security.py`: CSRF token derivation, request limits, and production configuration checks.
- `backend/app/documents.py`: isolated parsing of untrusted documents under CPU/memory/time limits.
- `backend/app/manage.py`: trusted-operator credit grants, ledger reconciliation, and legacy job recovery.
- `backend/app/activity.py`: 100-day history cleanup and expired-job refunds.
- `backend/app/control.py`: short-lived QR pairing, scoped controller tokens, WebSocket state/ack protocol, revoke/end APIs, and audit records.
- `backend/app/core.py`: SQLAlchemy entities. New tables are additive to the previous schema.

PostgreSQL holds permanent state. The v3 queue deliberately uses database reservations as its authoritative durable job source. Redis remains available in Compose for future caching; v3 generation correctness does not depend on Redis or RQ. The HTTP API never silently executes paid jobs inline when a queue is unavailable.

## Credits

Default generation cost: 2 credits. Default assistant edit cost: 1 credit. Manual edits and export: included. Both paid costs are environment-configurable and displayed from the server. Signup grants 30 credits after both contacts are verified.

A request reserves credits atomically. Success settles that reservation; failure refunds it once. An idempotency key reused with the same payload returns the original job, while a changed payload is rejected. Concurrent requests cannot spend the same remaining credits twice. Concurrent edits use version checks so a background task cannot overwrite a newer deck version.

Paid top-ups require explicit Stripe configuration and a server-selected price. No balance is increased based on a frontend success page. Only a valid, paid, matching webhook fulfills an order.

## Development and tests

Backend:

```sh
cd backend
python -m venv .venv
# Activate .venv using the command appropriate to your shell.
pip install -r requirements-lock.txt
uvicorn app.main:app --reload
# In another terminal, with the same database environment:
python -m app.worker
# Also run hourly retention/recovery maintenance:
python -m app.activity
python -m pytest -q
```

For the browser UI, keep `/api` proxied through the same origin. Set CORS_ORIGINS to the Vite origin (default development command uses port 5173). Docker uses port 3000.

Frontend:

```sh
cd frontend
npm ci
npm run dev
npm run build
```

Production document parsing is designed for the supplied Linux container. The parser uses Linux resource limits. Native Windows backend users should use Docker or WSL.

## Validation

20 backend tests passed. Frontend TypeScript/production build passed. Desktop and mobile browser checks passed for workspace, wallet, creation, and signup, with no page errors or horizontal overflow. A real local browser/API/worker flow passed login, generation, PPTX download, and assistant editing; the balance changed 30 → 28 → 27. Mobile control adds REST pairing and a typed WebSocket protocol; deploy behind HTTPS/WSS and set a strict `CORS_ORIGINS`/`FRONTEND_URL`.

Dependency audits reported no known vulnerabilities in the audited frontend dependencies and the tested backend environment after patching. This is a point-in-time dependency check, not a security certification.

## External services and remaining scope

Live LLM, Google login, OTP delivery, and Stripe payments need your credentials and provider-side setup. Tests use mocks for external identity/payment delivery and local outline generation for the browser end-to-end test. This environment did not run the full Docker/PostgreSQL stack or a live paid transaction.

Advanced visual PowerPoint QA, PDF export, image generation, cloud object storage, OCR, team collaboration, subscriptions, automatic payment refund/dispute reconciliation, and web research remain outside this release. The assistant can rewrite, translate, or combine slide edits when an LLM is configured, but it does not execute arbitrary tools or claim unsupported chart/image creation.
